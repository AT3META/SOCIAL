<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="Viewport for Instagram">
	<title>INSTAGRAM</title>
</head>
<body>
<!-- Place <div> tag where you want the feed to appear -->
<div id="curator-feed-default-feed-layout"><a href="https://curator.io" target="_blank" class="crt-logo crt-tag">Powered by Curator.io</a></div>
<!-- The Javascript can be moved to the end of the html page before the </body> tag -->
<script type="text/javascript">
/* curator-feed-default-feed-layout */
(function(){
var i, e, d = document, s = "script";i = d.createElement("script");i.async = 1;
i.src = "https://cdn.curator.io/published/fa34f8ca-6660-4af1-8f11-fd7cad0b0583.js";
e = d.getElementsByTagName(s)[0];e.parentNode.insertBefore(i, e);
})();
</script>
	<button class="btn btn-primary" align="center" onclick="NewTab()"> 
    INSTAGRAM 
    </button> 
    <script> 
        function NewTab() { 
            window.open("https://www.instagram.com", 
                    "", "width=850, height=650"); 
        } 
    </script>
</body>