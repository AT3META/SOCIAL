<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="Viewport for Facebook">
	<title>FACEBOOK</title>
</head>
<body>
<iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2F3ncircleN37WORK&tabs=timeline&width=500&height=666&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId=555087612042387" width="500" height="666" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowfullscreen="true" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"></iframe>
	<button class="btn btn-primary" align="center" onclick="NewTab()"> 
    FULLSCREEN 
    </button> 
    <script> 
        function NewTab() { 
            window.open("https://www.facebook.com", 
                    "", "width=888, height=666"); 
        } 
    </script>
</body>