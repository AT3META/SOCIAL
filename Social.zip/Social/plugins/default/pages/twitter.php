<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="Viewport for Twitter">
	<title>TWITTER</title>
</head>
<body>
<a class="twitter-timeline" href="https://twitter.com/3NCIRCLE?ref_src=twsrc%5Etfw">Tweets by 3NCIRCLE</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
	<button class="btn btn-primary" align="center" onclick="NewTab()"> 
    TWITTER 
    </button> 
    <script> 
        function NewTab() { 
            window.open("https://twitter.com", 
                    "", "width=850, height=650"); 
        } 
    </script>
</body>