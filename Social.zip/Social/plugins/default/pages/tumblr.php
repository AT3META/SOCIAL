<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="Viewport for Tumblr">
	<title>TUMBLR</title>
</head>
<body>
<iframe src="https://3ncircle.tumblr.com/" float="left" width="650" height="650" frameborder="0" allowfullscreen></iframe>
	<button class="btn btn-primary" align="center" onclick="NewTab()">
    TUMBLR
    </button> 
    <script> 
        function NewTab() { 
            window.open("https://www.tumblr.com", 
                    "", "width=850, height=650"); 
        } 
    </script>
</body>