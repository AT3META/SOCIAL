.menu-section-social i:before {
    font-family: FontAwesome;
    content: "\f2bd";
}
.menu-section-item-facebook:before {
    font-family: FontAwesome;
    content: "\f09a";
}
.menu-section-item-twitter:before {
    font-family: FontAwesome;
    content: "\f099";
}
.menu-section-item-instagram:before {
    font-family: FontAwesome;
    content: "\f16d";
}
.menu-section-item-tumblr:before {
    font-family: FontAwesome;
    content: "\f173";
}